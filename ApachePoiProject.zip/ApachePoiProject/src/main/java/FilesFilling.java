import java.io.File;
import java.io.IOException;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.time.Period;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Random;

import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.ss.usermodel.Row;

import com.lowagie.text.Font;
import com.lowagie.text.Paragraph;
import com.lowagie.text.pdf.PdfPTable;

public class FilesFilling {
	
    // ���������� ������ (rowNum) ������������� ����� (sheet)
    // �������  �� c��������� � ������ Excel �����
    // � ������ ������ � pdf ���� 
	public  void createFile(HSSFSheet sheet, int rowNum, PdfPTable table, Font myFont) throws IOException {
        CalculationOfObjects randomObject = new CalculationOfObjects();
        Row row = sheet.createRow(rowNum);
        String name = randomObject.getString("src\\main\\resources\\Name.txt"); //���
        String gender, surname, middlename; //���, �������, ��������
        if (name.charAt(name.length()-1)=='�'|| name.charAt(name.length()-1)=='�') {
        	gender = "�";
        	 surname=CalculationOfObjects.getData(randomObject.getListData("src\\main\\resources\\Surname.txt",gender));
        	 middlename=CalculationOfObjects.getData(randomObject.getListData("src\\main\\resources\\middlename.txt",gender));
        }
        else {
        	gender = "�";
        	surname=randomObject.getData(randomObject.getListData("src\\main\\resources\\Surname.txt",gender));
            middlename=randomObject.getData(randomObject.getListData("src\\main\\resources\\middlename.txt",gender));
        }
        row.createCell(0).setCellValue(name);
        table.addCell(new Paragraph(name,myFont));
        row.createCell(1).setCellValue(surname);
        table.addCell(new Paragraph(surname,myFont));
        row.createCell(2).setCellValue(middlename);
        table.addCell(new Paragraph(middlename,myFont));
        Random randomBirthday = new Random();
        int minDay = (int) LocalDate.of(1920, 1, 1).toEpochDay();
        int maxDay = (int) LocalDate.of(2001, 1, 1).toEpochDay();
        long randomDay = minDay + randomBirthday.nextInt(maxDay - minDay);
        LocalDate randombirthDate = LocalDate.ofEpochDay(randomDay); //��
        LocalDate randombirthDateFormat = LocalDate.parse(randombirthDate.toString(), DateTimeFormatter.ofPattern("yyyy-MM-dd")); //�� � ������ �������
        int age = randomObject.calculateAge(randombirthDate, LocalDate.now()); 
        row.createCell(3).setCellValue(age);
        table.addCell(new Paragraph(String.valueOf(age),myFont));
        row.createCell(4).setCellValue(gender);
        table.addCell(new Paragraph(gender,myFont));
        String birthDate = randombirthDateFormat.format(DateTimeFormatter.ofPattern("dd-MM-yyyy"));
        row.createCell(5).setCellValue(birthDate);   
        table.addCell(new Paragraph(birthDate,myFont));
        String inn = Arrays.toString(randomObject.calculateINN()).replaceAll("\\[|\\]|,|\\s", "");
        row.createCell(6).setCellValue(inn);
        table.addCell(new Paragraph(inn,myFont));
        int randomPostCode = randomObject.randBetween(200000, 100000);
        String postCode = String.valueOf(randomPostCode); //�������� ������
        row.createCell(7).setCellValue(postCode);     
        table.addCell(new Paragraph(String.valueOf(postCode),myFont));
        String country = randomObject.getString("src\\main\\resources\\Country.txt"); //������
        row.createCell(8).setCellValue(country);
        table.addCell(new Paragraph(country,myFont));
        String area = randomObject.getString("src\\main\\resources\\Area.txt");   //�������
        row.createCell(9).setCellValue(area);
        table.addCell(new Paragraph(area,myFont));
        String city = randomObject.getString("src\\main\\resources\\City.txt");  //�����
        row.createCell(10).setCellValue(city);
        table.addCell(new Paragraph(city,myFont));
        String street = randomObject.getString("src\\main\\resources\\Street.txt");  //�����
        row.createCell(11).setCellValue(street);
        table.addCell(new Paragraph(street,myFont));
        int randomHouse = CalculationOfObjects.randBetween(199, 1);
        String house = String.valueOf(randomHouse);  //���
        row.createCell(12).setCellValue(house);
        table.addCell(new Paragraph(house,myFont));
        int randomFlat = CalculationOfObjects.randBetween(999, 1); 
        String flat = String.valueOf(randomFlat); //��������
        row.createCell(13).setCellValue(flat);   
        table.addCell(new Paragraph(flat,myFont));
       
    }
	
	
	
        // ��������� ������ �������
	public  List<String> fillData() {
        CalculationOfObjects rowNumObject = new CalculationOfObjects();
        List<String> data = new ArrayList<>();
        int rowNum = rowNumObject.randBetween(1,29);
        for (int i = 0;i < rowNum;i++) {
        	data.add(new String());
        }
        return data;
    }
        
        public  void createApiFile(HSSFSheet sheet, int rowNum, PdfPTable table, Font myFont, RandomUserAPI user, Statement stat) throws IOException, SQLException {
        	CalculationOfObjects randomObject = new CalculationOfObjects();
            Row row = sheet.createRow(rowNum); 
            
            	 String gender = user.getGender().replace("\"", "");
            	 String name = user.getFirstName().replace("\"", "");
            	 String surname = user.getLastName().replace("\"", "");
            	 String middlename;           	
            	 if (gender.equals("female") ) {
            		 gender = "�";
                      middlename=randomObject.getData(randomObject.getListData("src\\main\\resources\\Middlename.txt", gender));
                 }
                 else {      
                	 gender = "�";
                 	  middlename=randomObject.getData(randomObject.getListData("src\\main\\resources\\middlename.txt", gender));
                 }
            	 String age = user.getAge().replace("\"", "");            	 
            	 String birthDateTime = user.getDate().replace("\"", "").substring(0, 10);
            	 String birthDate = birthDateTime.substring(8, 10)+"-"+birthDateTime.substring(5, 7)+"-"+birthDateTime.substring(0, 4);
            	 String birthDateSql = birthDateTime.substring(8, 10)+"-"+birthDateTime.substring(5, 7)+"-"+birthDateTime.substring(0, 2);
            	 String inn = Arrays.toString(randomObject.calculateINN()).replaceAll("\\[|\\]|,|\\s", "");
                 String postCode = user.getPostcode().replace("\"", ""); //�������� ������
            	 String country = randomObject.getString("src\\main\\resources\\Country.txt"); //������
            	 String area = user.getState().replace("\"", "");   //�������
            	 String city = user.getCity().replace("\"", "");  //�����
            	 String street = user.getStreet().replace("\"", "");  //�����
            	 int randomHouse = CalculationOfObjects.randBetween(199, 1);
                 String house = String.valueOf(randomHouse);  //���
                 int randomFlat = CalculationOfObjects.randBetween(999, 1); 
                 String flat = String.valueOf(randomFlat); //��������
               	 row.createCell(0).setCellValue(name);
                 table.addCell(new Paragraph(name,myFont));
                 row.createCell(1).setCellValue(surname);
                 table.addCell(new Paragraph(surname,myFont));
                 row.createCell(2).setCellValue(middlename);
                 table.addCell(new Paragraph(middlename,myFont));
                 row.createCell(3).setCellValue(age);
                 table.addCell(new Paragraph(age,myFont));
                 row.createCell(4).setCellValue(gender);
                 table.addCell(new Paragraph(gender,myFont));
                 row.createCell(5).setCellValue(birthDate);   
                 table.addCell(new Paragraph(birthDate,myFont));          
                 row.createCell(6).setCellValue(inn);
                 table.addCell(new Paragraph(inn,myFont));
                 row.createCell(7).setCellValue(postCode);     
                 table.addCell(new Paragraph(postCode,myFont));
                 row.createCell(8).setCellValue(country);
                 table.addCell(new Paragraph(country,myFont));
                 row.createCell(9).setCellValue(area);
                 table.addCell(new Paragraph(area,myFont));
                 row.createCell(10).setCellValue(city);
                 table.addCell(new Paragraph(city,myFont));
                 row.createCell(11).setCellValue(street);
                 table.addCell(new Paragraph(street,myFont));
                 row.createCell(12).setCellValue(house);
                 table.addCell(new Paragraph(house,myFont));
                 row.createCell(13).setCellValue(flat);   
                 table.addCell(new Paragraph(flat,myFont));  
                 int address_id = 1; int counter = 0; String sqlInsertIntoAddress, sqlInsertIntoPersons;
                 sqlInsertIntoAddress = "INSERT INTO users.address (id, postcode, country, region, city, street, house, flat) \r\n" + 
                     	 "VALUES (NULL, '" + postCode + "' ,'" + country + "' ,'" + area + "', '" + city + "', '" + street + "'," + house + "," + flat +");";
                 stat.executeUpdate(sqlInsertIntoAddress);
                 String sqlGetAddressId = "select max(id) from users.address;";     	  	 
                 ResultSet resultOfSqlGetAddressId=stat.executeQuery(sqlGetAddressId);
                 while (resultOfSqlGetAddressId.next()) {
                	  address_id = resultOfSqlGetAddressId.getInt(1);
                	 }                 
                 String sqlGetExistPerson = "select count(*) from users.persons where surname = '"+surname+"' and name = '" +name +"' and middlename = '" + middlename + "';";     	  	 
                 ResultSet resultOfSqlGetExistPerson=stat.executeQuery(sqlGetExistPerson); 
                 while (resultOfSqlGetExistPerson.next()) {
                	 counter = resultOfSqlGetExistPerson.getInt(1);
               	 }
                 if (counter == 0) {
                	 sqlInsertIntoPersons = "INSERT INTO users.persons (id, surname, name, middlename, birthday, gender, inn, address_id) " +
                 			 "VALUES (NULL, '" + surname + "', '" + name + "', '" + middlename + "', '" + birthDateSql + "', '" + gender.toString() + "', '" + inn + "', '" + address_id + "');";               
                	 stat.executeUpdate(sqlInsertIntoPersons);
                 } else {
                	 sqlInsertIntoPersons = "UPDATE users.persons SET birthday = '" + birthDateSql + "', gender = '" + gender + "', inn = '" + inn + "', address_id = '" + address_id + "' WHERE surname = '" + surname + "', name = '" + name + "', middlename =  '" + middlename + "';";
                 			  	 stat.executeUpdate(sqlInsertIntoPersons);
                 }              
       }



		public void createDataBaseFile(HSSFSheet sheet, int rowNum, PdfPTable table, Font myFont, Statement stat) throws IOException, SQLException {
			CalculationOfObjects randomObject = new CalculationOfObjects();
	        Row row = sheet.createRow(rowNum);
	        String name = null, gender = null, surname = null, middlename = null, inn = null,  postCode = null, country = null, area = null, city = null, street = null;
			String birthDate = null;
	        int house = 0, flat = 0, age = 0, id, maxId = 0, minId = 0;
	        String sqlGetId = "select min(id), max(id) from users.address;";     	  	 
            ResultSet resultOfSqlGetId=stat.executeQuery(sqlGetId);
            while (resultOfSqlGetId.next()) {
           	  minId = resultOfSqlGetId.getInt(1);
           	  maxId = resultOfSqlGetId.getInt(2);
           	 }   
            id = randomObject.randBetween(minId, maxId);
	        String sqlGetPerson = "select * from users.persons where address_id = " + id + ";";     	  	 
            ResultSet resultOfSqlGetPerson=stat.executeQuery(sqlGetPerson); 
            while (resultOfSqlGetPerson.next()) {
             surname = resultOfSqlGetPerson.getString(2);
           	 name = resultOfSqlGetPerson.getString(3);
           	 middlename = resultOfSqlGetPerson.getString(4);
           	 birthDate = resultOfSqlGetPerson.getString(5);
           	 gender = resultOfSqlGetPerson.getString(6);
           	 inn = resultOfSqlGetPerson.getString(7);
          	 }
            String sqlGetAddress = "select * from users.address where id = " + id + ";";     	  	 
            ResultSet resultOfSqlGetAddress=stat.executeQuery(sqlGetAddress); 
            while (resultOfSqlGetAddress.next()) {
             postCode = resultOfSqlGetAddress.getString(2);
             country = resultOfSqlGetAddress.getString(3);
             area = resultOfSqlGetAddress.getString(4);
             city = resultOfSqlGetAddress.getString(5);
             street = resultOfSqlGetAddress.getString(6);
             house = resultOfSqlGetAddress.getInt(7);
             flat = resultOfSqlGetAddress.getInt(8);
          	 }
            String sqlGetAge = "SELECT ABS(YEAR(CURRENT_DATE) - YEAR(birthday))  FROM users.persons where address_id = " + id + ";";
            ResultSet resultOfSqlGetAge=stat.executeQuery(sqlGetAge); 
            while (resultOfSqlGetAge.next()) {
             age = resultOfSqlGetAge.getInt(1);
            }
            row.createCell(0).setCellValue(name);
	        table.addCell(new Paragraph(name,myFont));
	        row.createCell(1).setCellValue(surname);
	        table.addCell(new Paragraph(surname,myFont));
	        row.createCell(2).setCellValue(middlename);
	        table.addCell(new Paragraph(middlename,myFont));
	        row.createCell(3).setCellValue(age);
	        table.addCell(new Paragraph(String.valueOf(age),myFont));
	        row.createCell(4).setCellValue(gender);
	        table.addCell(new Paragraph(gender,myFont));
	        row.createCell(5).setCellValue(birthDate);   
	        table.addCell(new Paragraph(birthDate,myFont));
	        row.createCell(6).setCellValue(inn);
	        table.addCell(new Paragraph(inn,myFont));
	        row.createCell(7).setCellValue(postCode);     
	        table.addCell(new Paragraph(String.valueOf(postCode),myFont));
	        row.createCell(8).setCellValue(country);
	        table.addCell(new Paragraph(country,myFont));
	        row.createCell(9).setCellValue(area);
	        table.addCell(new Paragraph(area,myFont));
	        row.createCell(10).setCellValue(city);
	        table.addCell(new Paragraph(city,myFont));
	        row.createCell(11).setCellValue(street);
	        table.addCell(new Paragraph(street,myFont));
	        int randomHouse = CalculationOfObjects.randBetween(199, 1);
	        row.createCell(12).setCellValue(house);
	        table.addCell(new Paragraph(String.valueOf(house),myFont));
	        int randomFlat = CalculationOfObjects.randBetween(999, 1); 
	        row.createCell(13).setCellValue(flat);   
	        table.addCell(new Paragraph(String.valueOf(flat),myFont));			
		}
}
