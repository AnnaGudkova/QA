package randomUserApi;
import java.io.IOException;

import com.google.gson.JsonSyntaxException;

public interface Parser<T> {
	T parse() throws JsonSyntaxException, IOException;
}
