package randomUserApi;
import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.UnknownHostException;

public class AvailabilityOfInternet {
	 public static boolean isInternetAvailable() throws IOException
	    {
		 try(Socket socket = new Socket())
	        {
	            int port = 80;
	            InetSocketAddress socketAddress = new InetSocketAddress("randomuser.me", port);
	            socket.connect(socketAddress, 3000);
	            return true;
	        }
	        catch(UnknownHostException unknownHost)
	        {
	        	System.out.println("No internet connection");
	            return false;
	           
	        }
		
		 }
}