package randomUserApi;
 import java.io.IOException;

import com.google.gson.JsonElement;
 import com.google.gson.JsonParser;
import com.google.gson.JsonSyntaxException;
public class JsonParserImpl implements Parser<RandomUserAPI> {

    private HttpClient httpClient;

    public JsonParserImpl(HttpClient httpClient) {
        this.httpClient = httpClient;
    }

    public RandomUserAPI parse() throws JsonSyntaxException, IOException {
        JsonElement jsonTree = new JsonParser().parse(httpClient.getData().toString());
        if (jsonTree.isJsonObject()) {
            JsonElement results = jsonTree.getAsJsonObject().get("results");
            if (results.isJsonArray()) {
                JsonElement name = getArrayObject(results, "name");
                JsonElement firstName = getValue(name, "first");
                JsonElement lastName = getValue(name, "last");

                JsonElement gender = getArrayObject(results, "gender");
                
                JsonElement dob = getArrayObject(results, "dob");
                JsonElement date = getValue(dob, "date");
                JsonElement age = getValue(dob, "age");

                JsonElement location = getArrayObject(results, "location");
                JsonElement state = getValue(location, "state");
                JsonElement city = getValue(location, "city");
                JsonElement street = getValue(location, "street");
                JsonElement postcode = getValue(location, "postcode");

                return new RandomUserAPI(firstName.toString(), lastName.toString(), gender.toString(), date.toString(),
                		age.toString(), state.toString(), city.toString(), street.toString(), postcode.toString());
            }
        }
        
        return null;
    }

    private JsonElement getArrayObject(JsonElement array, String objectName) {
        return array.getAsJsonArray().get(0).getAsJsonObject().get(objectName);
    }

    private JsonElement getValue(JsonElement object, String objectName) {
        if (object.isJsonObject()) {
            return object.getAsJsonObject().get(objectName);
        }
        return null;
    }
}
