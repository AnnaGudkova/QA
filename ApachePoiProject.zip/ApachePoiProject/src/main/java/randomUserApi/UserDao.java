package randomUserApi;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import com.google.gson.JsonSyntaxException;

public class UserDao {
	 private final int count = 1 + (int)Math.round(Math.random() * (29));
	 
     private Parser<RandomUserAPI> parser;

     private List<RandomUserAPI> users = new ArrayList<>();

     public UserDao(Parser<RandomUserAPI> parser) {
         this.parser = parser;
     }

     public void addUser() throws JsonSyntaxException, IOException {
    	    for (int i = 0; i < count; i++) {
             users.add(parser.parse());
         }
    }

     public List<RandomUserAPI> getAll() {
         return users;
     }
}
