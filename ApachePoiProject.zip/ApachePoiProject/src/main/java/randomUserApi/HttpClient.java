package randomUserApi;
import java.io.IOException;

public interface HttpClient<T> {
	T getData() throws IOException;
}
