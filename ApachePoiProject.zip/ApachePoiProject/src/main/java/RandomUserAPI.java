import com.google.gson.JsonElement;

public class RandomUserAPI {
        private String firstName;
        private String lastName;
        private String gender;
        private String date;
        private String age;
        private String state;
        private String city;
        private String street;
        private String postcode;
        public RandomUserAPI(String firstName,
                    String lastName,
                    String gender,
                    String date,
                    String age,
                    String state,
                    String city,
                    String street,
                    String postcode) {
            this.firstName = firstName;
            this.lastName = lastName;
            this.gender = gender;
            this.date = date;
            this.age = age;
            this.state = state;
            this.city = city;
            this.street = street;
            this.postcode = postcode;
}
        
        public String getFirstName() {
            return firstName;
        }

        public String getLastName() {
            return lastName;
        }

        public String getGender() {
            return gender;
        }

        public String getDate() {
            return date;
        }

        public String getAge() {
            return age;
        }

        public String getState() {
            return state;
        }

        public String getCity() {
            return city;
        }

        public String getStreet() {
            return street;
        }
        
        public String getPostcode() {
            return postcode;
        }
}
